Gorescu Diana - 332CC
Tema 1 APD

Pornind de la schelet am decis ca trebuie sa paralelizez functiile rescale, sample_grid si ultima, march. Mai intai, mi-am creat o structura cu toate variabilele date ca parametrii in functiile mentionate mai sus, pentru a nu avea variabile globale. Totodata, am facut o functie de thread-uri f, in care am paralelizat cu atentie functiile. In main, am urmat structura scheletului cu citiri, alocari , scrieri, dezalocari si distrugere de bariera.

